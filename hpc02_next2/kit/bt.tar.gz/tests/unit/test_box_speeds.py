"""hpc01-e5: ranked results use speeds re-measured on the evaluator's machine."""

import json
import shutil
import sys
from pathlib import Path

from bittrellis.frontier.report import load_row

ROOT = Path(__file__).resolve().parents[2]
SEEDS = ROOT / "results/feasibility/artifacts"
sys.path.insert(0, str(ROOT / "evaluator"))
import speeds  # noqa: E402

FLOORS = {"rp_kl": 0.002, "decode_tps": 0.01, "prefill_tps": 0.03, "peak_gpu_gib": 0.10}


def test_a_ranked_result_takes_its_speed_from_this_machine(tmp_path):
    v0 = SEEDS / "V0-baseline-rebuild"
    cid = json.loads((v0 / "candidate.json").read_text())["id"]
    (tmp_path / cid).mkdir()
    here = {**json.loads((v0 / "performance.json").read_text()), "prefill_tps": 16650.0}
    (tmp_path / cid / "performance.json").write_text(json.dumps(here))
    stored = json.loads((v0 / "performance.json").read_text())["prefill_tps"]
    assert load_row(v0).prefill_tps == stored                     # stored: the machine that measured the seeds
    assert load_row(v0, tmp_path).prefill_tps == 16650.0          # this machine
    assert load_row(v0, tmp_path / "none").prefill_tps == stored


def test_external_references_keep_their_own_numbers(tmp_path):
    ext = next(d for d in sorted(SEEDS.iterdir()) if d.is_dir() and json.loads((d / "candidate.json").read_text()).get("kind") == "external"
               and (d / "performance.json").exists() and (d / "quality.json").exists())
    cid = json.loads((ext / "candidate.json").read_text())["id"]
    (tmp_path / cid).mkdir()
    shutil.copy(ext / "performance.json", tmp_path / cid / "performance.json")
    (tmp_path / cid / "performance.json").write_text(json.dumps({"decode_tps": 1, "prefill_tps": 1, "peak_gpu_gib": 1}))
    assert load_row(ext, tmp_path).decode_tps == load_row(ext).decode_tps


def test_drift_is_judged_by_the_noise_floors():
    base = {"decode_tps": 95.0, "prefill_tps": 16650.0, "peak_gpu_gib": 22.0}
    assert speeds.drifted(base, {**base, "decode_tps": 95.5, "prefill_tps": 16300.0}, FLOORS) == []   # within 1% / 3%
    assert speeds.drifted(base, {**base, "prefill_tps": 14760.0}, FLOORS) == ["prefill_tps 16650 -> 14760"]
    assert speeds.drifted(base, {**base, "peak_gpu_gib": 22.3}, FLOORS) == ["peak_gpu_gib 22 -> 22.3"]


def test_only_ranked_references_with_a_recipe_are_measured():
    names = {p.name for p in speeds.references([SEEDS])}
    assert "V0-baseline-rebuild" in names and len(names) == 9     # the two external references are context only


def test_drift_must_show_at_two_prs_in_a_row(tmp_path):
    v0 = SEEDS / "V0-baseline-rebuild"
    cand = json.loads((v0 / "candidate.json").read_text())
    stored = {"decode_tps": 95.7, "prefill_tps": 16879.0, "peak_gpu_gib": 22.016}
    readings = iter([22.135, 22.016, 22.135, 22.140])   # blip, back to normal, then a lasting move

    def fake_run(cmd, cwd, log):
        out = Path(cmd[cmd.index("--out") + 1])
        out.mkdir(parents=True, exist_ok=True)
        if cmd[3] == "build":
            (out / "bittrellis_build.json").write_text("{}")
        else:
            (out / "candidate.json").write_text(json.dumps({"id": cand["id"]}))
            (out / "performance.json").write_text(json.dumps({**stored, "peak_gpu_gib": next(readings)}))
        return 0

    bs = speeds.BoxSpeeds(tmp_path, fake_run, ["python", "-m", "bittrellis.cli"], [], "/none", FLOORS, "V0-baseline-rebuild")
    (bs.dir / cand["id"]).mkdir(parents=True)
    (bs.dir / cand["id"] / "performance.json").write_text(json.dumps(stored))
    assert bs.check_drift(v0) == []                               # one reading past the floor: noted only
    assert bs.check_drift(v0) == []                               # back within noise: the note is cleared
    assert bs.check_drift(v0) == []
    assert bs.check_drift(v0) == ["peak_gpu_gib 22.016 -> 22.14"]  # two PRs in a row: re-measure


def test_a_merged_result_measured_here_is_reused_not_rebuilt(tmp_path, monkeypatch):
    here = {"gpu": "RTX 5090, 595.71.05", "cuda": "13.0", "cpu": "9950X", "sparkinfer_commit": "b1ed168"}
    monkeypatch.setattr(speeds, "machine", lambda _: here)
    bs = speeds.BoxSpeeds(tmp_path, None, [], [], "/none", FLOORS, "V0-baseline-rebuild")
    bs.dir.mkdir()
    (bs.dir / "machine.json").write_text(json.dumps({"machine": here, "measured_utc": "2026-10-02T20:43:28Z",
                                                     "calibrated_utc": "2026-10-02T16:25:40Z"}))

    def artifact(name, cid, env_time, **env):
        art = tmp_path / name
        art.mkdir()
        (art / "candidate.json").write_text(json.dumps({"id": cid, "name": name}))
        (art / "performance.json").write_text(json.dumps({"decode_tps": 93.3, "prefill_tps": 15828.0, "peak_gpu_gib": 22.39}))
        (art / "environment.json").write_text(json.dumps({**here, **env, "time_utc": env_time}))
        return art

    assert bs.adopt(artifact("merged-here", "a" * 16, "2026-10-02T19:02:26Z"))
    assert bs.has("a" * 16)
    assert not bs.adopt(artifact("before-calibration", "b" * 16, "2026-10-02T15:00:00Z"))   # older speeds: rebuild
    assert not bs.adopt(artifact("other-box", "c" * 16, "2026-10-02T19:00:00Z", cpu="5900X"))  # another machine


def test_speed_runs_build_regenerable_encoders_with_default_bytes():
    blockfit = {"schema": "bittrellis/manifest@2", "track": "HPC-01", "name": "x", "default": "NVFP4",
                "rules": [{"match": "L*.mlp", "format": "NVFP4", "quantizer": "rtn"},
                          {"match": "L*.gdn.qkv", "format": "FP8", "quantizer": "rtn"},
                          {"match": "L*.attn.*", "format": "NVFP4", "quantizer": "unsloth"}],
                "expanded": {"L0.mlp": {}}}
    built, changed = speeds.speed_manifest(blockfit)
    assert changed and built["name"] == "x-speed" and "expanded" not in built
    assert "quantizer" not in built["rules"][0]                    # regenerable, not the NVFP4 default: default bytes
    assert built["rules"][1]["quantizer"] == "rtn"                 # already FP8's default
    assert built["rules"][2]["quantizer"] == "unsloth"             # attested bytes are copied as they are
    assert speeds.speed_manifest({**blockfit, "rules": blockfit["rules"][1:]}) == ({**blockfit, "rules": blockfit["rules"][1:]}, False)
    a = {"expanded": {"L0.mlp": {"source_format": "NVFP4", "quantizer": "rtn@v1", "execution": {"decode_b1": "NVFP4"}}}}
    b = {"expanded": {"L0.mlp": {"source_format": "NVFP4", "quantizer": "baseline@v1", "execution": {"decode_b1": "NVFP4"}}}}
    assert speeds.kernels(a) == speeds.kernels(b)                   # bytes differ, kernels do not


def test_hpc02_speed_runs_write_regenerable_encoders_with_kq_rtn():
    from bittrellis import hpc02

    hpc02.register(hpc02.Encoder("slow_kq", 1, "regenerable", lambda ctx, fmt: b""))
    m = {"name": "r", "default": "Q8_0", "encoders": {"Q4_K": "slow_kq", "Q8_0": "unsloth_ud"},
         "rules": [{"match": "L*.exps.*", "format": "Q4_K", "encoder": "slow_kq", "params": {"x": 1}}],
         "modules": {"lm_head": {"format": "Q6_K", "encoder": "slow_kq"}, "embed": "Q8_0"}}
    built, changed = speeds.speed_manifest_gguf(m)
    assert changed and built["name"] == "r-speed"
    assert built["encoders"] == {"Q4_K": "kq_rtn", "Q8_0": "unsloth_ud"}           # attested bytes are only copied
    assert built["rules"][0] == {"match": "L*.exps.*", "format": "Q4_K", "encoder": "kq_rtn"}
    assert built["modules"]["lm_head"]["encoder"] == "kq_rtn" and m["modules"]["lm_head"]["encoder"] == "slow_kq"
    assert speeds.speed_manifest_gguf({"name": "v0", "default": "Q8_0", "encoders": {"Q8_0": "unsloth_ud"}}) == \
        ({"name": "v0", "default": "Q8_0", "encoders": {"Q8_0": "unsloth_ud"}}, False)
    hpc02.ENCODERS.pop("slow_kq")
